<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Tarefas</title>
</head>
<body>

    <h1>Lista de Tarefas:</h1>

    <?php 
        session_start();
        echo var_dump($_SESSION);


        require_once "banco-antigo.php";

        $novaTarefa = $_POST['tarefa'] ?? null;
        if(!is_null($novaTarefa)){
            $banco->query("INSERT INTO tarefas(cod, tarefa) 
            VALUES (NULL, '$novaTarefa')");
        }

        $busca = $banco->query("SELECT * FROM tarefas");

        // echo print_r($busca);
        
        while($obj_lista = $busca->fetch_object()){
            echo "<br> - $obj_lista->tarefa";
            // echo print_r($obj_lista);
        }
    
    ?>

    <hr>
    <h1>Adicionar Tarefa:</h1>
    <form action="" method="post">
        <input type="text" name="tarefa" id="">
        <input type="submit" value="Adicionar">
    </form>

    
</body>
</html>